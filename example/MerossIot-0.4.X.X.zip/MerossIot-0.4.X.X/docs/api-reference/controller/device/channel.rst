ChannelInfo
-----------

.. autoclass:: meross_iot.controller.device.ChannelInfo
   :members:
