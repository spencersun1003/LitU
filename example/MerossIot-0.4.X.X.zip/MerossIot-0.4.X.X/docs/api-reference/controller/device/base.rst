BaseDevice
----------

.. autoclass:: meross_iot.controller.device.BaseDevice
   :members:
