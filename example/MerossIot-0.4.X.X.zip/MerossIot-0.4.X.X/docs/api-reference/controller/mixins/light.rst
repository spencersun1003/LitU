LightMixin
----------

.. autoclass:: meross_iot.controller.mixins.light.LightMixin
   :members:
