DNDMixin
------------

.. autoclass:: meross_iot.controller.mixins.dnd.SystemDndMixin
   :members:
