ConsumptionXMixin
-----------------

.. autoclass:: meross_iot.controller.mixins.consumption.ConsumptionXMixin
   :members:
