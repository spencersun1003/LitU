RollerShutterMixin
------------

.. autoclass:: meross_iot.controller.mixins.roller_shutter.RollerShutterTimerMixin
   :members:
