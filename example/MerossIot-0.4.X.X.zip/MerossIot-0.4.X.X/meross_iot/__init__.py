"""
The MerossIot library is a low-level python library which interacts with the Meross Cloud
backend systems in order to control Meross devices. You can consider it as a library
upon which you can build automation scripts.
"""
name = "meross_iot"
